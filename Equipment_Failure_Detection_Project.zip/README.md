# 🏭 Real-Time Industrial Equipment Failure Detection System

### Production-Grade Streaming Machine Learning Pipeline

---

## 💼 Business Problem & Impact

Industrial equipment failures lead to **massive financial losses**, production downtime, and safety risks. Traditional maintenance systems are reactive — they detect issues only after failure occurs.

This project solves that by enabling:
- 🔍 **Early anomaly detection** in machine behavior
- ⚡ **Real-time monitoring of equipment health**
- 🛠️ **Predictive maintenance instead of reactive repair**
- 💰 **Reduced operational downtime and cost savings**

---

## 🎯 System Objective

Design and implement a **real-time intelligent monitoring system** that:
- Continuously ingests sensor data streams
- Detects abnormal machine behavior instantly
- Adapts to changing data patterns over time (adaptive thresholds)
- Provides actionable multi-level alerts and visual insights

---

## 🏗️ System Architecture

### 🔁 End-to-End Pipeline

```
[Sensor Simulation Engine]
        ↓
[Kafka Producer]
        ↓
[Kafka Topic: sensor_stream]
        ↓
[Streaming Consumer Engine]
        ↓
[Sliding Window Processor (size=10)]
        ↓
[Feature Engineering Layer (15 features)]
        ↓
[ML Inference Engine (Isolation Forest)]
        ↓
[Adaptive Threshold + Rule-Based Fallback]
        ↓
[Multi-Level Alert System (LOW / MEDIUM / HIGH)]
        ↓
[FastAPI Backend (/predict, /health, /system_metrics, /recent_anomalies)]
        ↓
[Streamlit Dashboard (Live Charts, Anomaly Feed, Drift Indicators)]
        ↓
[Monitoring: MLflow (Experiment Tracking) + EvidentlyAI (Drift Detection)]
```

---

## 🧪 Advanced Sensor Simulation Engine

Since real IoT hardware is unavailable, we built a **high-fidelity multi-stage simulation**.

### Simulated Sensors

| Sensor | Base Distribution | Failure Mode | Additional |
|---|---|---|---|
| 🌡️ Temperature | Gaussian ~70°C ± 2 | Spikes +20–40°C | Gradual drift over time |
| ⚙️ Vibration | Gaussian ~0.5G ± 0.05 | Jumps +1.5–3.0G | Correlated with temperature |
| 💧 Humidity | Sinusoidal ~40% ± 10 | — | Day/night environmental cycles |

### 🔥 Advanced Realism Enhancements

- **Correlated Failures**: Temperature ↑ and Vibration ↑ spike together (physically realistic)
- **Multi-Stage Degradation State Machine**: `NORMAL → DEGRADING → UNSTABLE → FAILURE → RESET`
- **Noise Injection**: Random Gaussian noise simulates real sensor inaccuracies
- **Configurable Anomaly Rate**: Default 5% probability, tunable in `config.yaml`

### Dataset Approach

> ⚠️ **We do NOT use a static CSV dataset.** Instead, we generate an infinite, realistic data stream programmatically. This more closely mirrors real-world IoT deployments where data arrives continuously.
>
> **For training**, `model/train.py` generates 5,000 synthetic samples with the exact same statistical profile as the live simulator, including 2% injected correlated anomalies. This training set is used to fit the Isolation Forest's decision boundary.
>
> **For Colab training**, upload `train_colab.ipynb` to Google Colab and run it. It reproduces the same data generation + model training workflow and exports `model.pkl` for download.

---

## 🧠 Feature Engineering (Sliding Window Strategy)

Raw streaming data is too noisy for direct ML inference. We apply a **sliding window** approach:

- **Window Size**: 10 seconds (configurable in `config.yaml`)
- **Rolling Buffer**: Maintains the last 10 readings in memory

### Extracted Features (per sensor)

| Feature | Description |
|---|---|
| `_mean` | Rolling average over window |
| `_std` | Rolling standard deviation (volatility) |
| `_min` | Minimum value in window |
| `_max` | Maximum value in window |
| `_roc` | Rate of change (current − oldest in window) |

**Result**: 3 sensors × 5 features = **15-dimensional feature vector per second**

---

## 🤖 Machine Learning Layer

### Primary Model: Isolation Forest

| Property | Value |
|---|---|
| Algorithm | `sklearn.ensemble.IsolationForest` |
| Type | Unsupervised anomaly detection |
| n_estimators | 100 |
| contamination | 0.05 (top 5% as anomalies) |
| Output | `1` = Normal, `-1` = Anomaly |

### Why Isolation Forest?
- Works **without labeled failure data** (unsupervised)
- Efficient for **high-dimensional streaming data**
- Robust to noise — isolates outliers via random partitioning

### Adaptive Thresholding
Instead of a fixed cutoff, the system maintains a **rolling window of anomaly scores** and dynamically computes:
```
Threshold = mean(recent_scores) − 2 × std(recent_scores)
```
This makes the system self-adjusting to changing equipment behavior.

### Rule-Based Fallback
When ML model confidence is borderline, a rule-based engine activates:
- Temperature > 95°C → Anomaly
- Vibration > 2.0G → Anomaly

If both ML and rules agree, the alert severity is **automatically upgraded**.

---

## 🚨 Intelligent Alert System

### Multi-Level Alerting

| Level | Anomaly Score | Meaning |
|---|---|---|
| 🟢 LOW | ≤ −0.2 | Minor deviation |
| 🟡 MEDIUM | ≤ −0.4 | Suspicious pattern |
| 🔴 HIGH | ≤ −0.6 | Critical failure risk |

### Hybrid Decision Logic
- **ML-based**: Isolation Forest score + adaptive threshold
- **Rule-based**: Physical sensor threshold validation
- **Upgrade**: If both ML + rules trigger → severity increases

### Persistent Storage
All alerts are logged to `storage/anomaly_logs.json` as newline-delimited JSON for audit trails.

---

## 📊 Observability & Monitoring

### 📉 Drift Detection (EvidentlyAI)
- Compares live streaming distributions vs. training reference snapshot
- Uses Kolmogorov-Smirnov statistical tests
- Runs automatically every 100 records (configurable)
- Triggers retraining warnings when drift exceeds thresholds

### 🔁 Model Lifecycle (MLflow)
- Tracks all training experiments in SQLite backend
- Logs: contamination, window_size, n_estimators, baseline scores
- Stores serialized model artifacts for versioning

### System Metrics (API)
- `throughput_records_per_sec` — Processing speed
- `anomaly_rate_percent` — Live anomaly percentage
- `total_records_processed` — Cumulative counter
- `uptime_seconds` — API uptime

---

## 🌐 API Layer (FastAPI)

| Endpoint | Method | Description |
|---|---|---|
| `/health` | GET | System health + uptime |
| `/predict` | POST | Ingest prediction results |
| `/recent_anomalies/` | GET | Latest anomaly records |
| `/live_data/` | GET | Last 100 records for dashboard |
| `/system_metrics` | GET | Throughput, anomaly rate, uptime |

---

## 📊 Dashboard (Streamlit + Plotly)

| Feature | Description |
|---|---|
| 📈 Live Sensor Trends | Real-time temperature, vibration, humidity charts |
| 🔥 Anomaly Score Timeline | Score plot with adaptive threshold overlay |
| 📊 Correlation Heatmap | Sensor-to-anomaly Pearson correlation matrix |
| ⚠️ Anomaly Alert Feed | Color-coded (🟢🟡🔴) real-time alert cards |
| 📉 Drift Indicators | Baseline deviation metrics for each sensor |
| 📋 Raw Data Table | Optional: toggleable raw stream view |

---

## 📁 Project Structure

```
project/
│
├── config/
│   └── config.yaml              # All configurable parameters
│
├── data_generator/
│   └── sensor_simulator.py      # Multi-stage degradation simulator
│
├── kafka/
│   ├── producer.py              # Kafka producer wrapper
│   └── consumer.py              # Kafka consumer wrapper
│
├── preprocessing/
│   └── window_features.py       # 15-dim sliding window features
│
├── model/
│   ├── train.py                 # Isolation Forest training + MLflow
│   ├── predict.py               # Real-time inference engine
│   └── model.pkl                # Serialized trained model
│
├── monitoring/
│   ├── mlflow_tracking.py       # MLflow experiment tracking
│   └── drift_detection.py       # EvidentlyAI drift detection
│
├── alerting/
│   └── alert_manager.py         # Multi-level hybrid alert system
│
├── api/
│   └── main.py                  # FastAPI backend (5 endpoints)
│
├── dashboard/
│   └── app.py                   # Streamlit + Plotly dashboard
│
├── utils/
│   ├── logger.py                # Structured production logging
│   └── helpers.py               # Config loader + utilities
│
├── storage/
│   └── anomaly_logs.json        # Persistent anomaly audit trail
│
├── docker/
│   └── docker-compose.yml       # Kafka + Zookeeper + API + Dashboard
│
├── Dockerfile                   # Python service container
├── train_colab.ipynb            # Google Colab training notebook
├── requirements.txt             # All Python dependencies
└── README.md                    # This file
```

---

## 🚀 Setup & Execution

### Prerequisites
- Python 3.10+
- Docker Desktop (for Kafka) OR a local Kafka broker on `localhost:9092`

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Start Kafka (via Docker)
```bash
docker-compose -f docker/docker-compose.yml up -d zookeeper kafka
```

### 3. Train the Model
```bash
python -m model.train
```
*This generates `model/model.pkl` with the trained Isolation Forest + baseline stats + reference data.*

### 4. Start FastAPI Backend (Terminal 1)
```bash
uvicorn api.main:app --reload
```

### 5. Start Streamlit Dashboard (Terminal 2)
```bash
streamlit run dashboard/app.py
```

### 6. Start Inference Engine (Terminal 3)
```bash
python -m model.predict
```

### 7. Start Sensor Simulator (Terminal 4)
```bash
python -m data_generator.sensor_simulator
```

*Data will now stream through the entire pipeline — watch the dashboard light up!*

---

## 🎤 Interview Explanation

### 🔹 30-Second Pitch
> Built a real-time ML system to detect industrial equipment failures by streaming simulated sensor data through Kafka, applying sliding window feature engineering, and using Isolation Forest with adaptive thresholds for anomaly detection — complete with multi-level alerting, drift monitoring, and a live dashboard.

### 🔹 2-Minute Deep Dive
> Designed a production-style streaming ML pipeline where a multi-stage degradation simulator generates correlated sensor telemetry (temperature, vibration, humidity) ingested via Kafka. The consumer applies a 10-second sliding window to extract a 15-dimensional feature vector per second, which feeds an Isolation Forest model. The system uses adaptive thresholding (rolling mean − 2σ) with a rule-based fallback for edge cases. Anomalies trigger a multi-level alert system (LOW/MEDIUM/HIGH) with both ML and physics-based validation. EvidentlyAI monitors for concept drift against training baselines, while MLflow tracks model experiments. Results are served via FastAPI and visualized on a Streamlit dashboard featuring live trends, correlation heatmaps, and an anomaly timeline with the adaptive threshold overlay.

---

## 🚀 Future Enhancements
- Edge deployment (ONNX / TensorRT)
- Deep learning models (LSTM for temporal sequences)
- Cloud deployment (AWS Kinesis / GCP Pub/Sub)
- Real IoT hardware integration
- Automated retraining pipeline on drift detection
