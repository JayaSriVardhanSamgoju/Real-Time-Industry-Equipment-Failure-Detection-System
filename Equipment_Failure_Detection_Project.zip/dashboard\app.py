import streamlit as st
import pandas as pd
import requests
import time
import plotly.express as px
import plotly.graph_objects as go
from utils.helpers import load_config

config = load_config()
API_URL = f"http://localhost:{config['api']['port']}"

st.set_page_config(page_title="Equipment Failure Dashboard", layout="wide", page_icon="🏭")

# ──────────────────────────────────────────────
#  Custom CSS
# ──────────────────────────────────────────────
st.markdown("""
<style>
    .metric-card {
        background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
        border-radius: 12px; padding: 20px; text-align: center;
        color: white; margin: 5px; border: 1px solid #475569;
    }
    .metric-card h2 { font-size: 2em; margin: 0; }
    .metric-card p { margin: 4px 0 0 0; opacity: 0.8; font-size: 0.9em; }
    .alert-high { background: #dc2626; color: white; padding: 8px 16px; border-radius: 8px; margin: 2px; }
    .alert-medium { background: #f59e0b; color: black; padding: 8px 16px; border-radius: 8px; margin: 2px; }
    .alert-low { background: #22c55e; color: white; padding: 8px 16px; border-radius: 8px; margin: 2px; }
</style>
""", unsafe_allow_html=True)

st.title("🏭 Real-Time Equipment Failure Monitoring")
st.caption("Streaming Isolation Forest Anomaly Detection Pipeline")

# ──────────────────────────────────────────────
#  Sidebar Controls
# ──────────────────────────────────────────────
st.sidebar.header("⚙️ Dashboard Controls")
refresh_rate = st.sidebar.slider("Refresh Interval (sec)", 1, 10, config["dashboard"]["refresh_rate_sec"])
show_raw = st.sidebar.checkbox("Show Raw Data Table", False)

# ──────────────────────────────────────────────
#  API Fetchers
# ──────────────────────────────────────────────
def fetch(endpoint):
    try:
        r = requests.get(f"{API_URL}/{endpoint}", timeout=2)
        return r.json() if r.status_code == 200 else []
    except Exception:
        return []

placeholder = st.empty()

# ──────────────────────────────────────────────
#  Main Loop
# ──────────────────────────────────────────────
while True:
    live_data = fetch("live_data/")
    anomalies = fetch("recent_anomalies/")
    metrics = fetch("system_metrics")

    with placeholder.container():
        # ── TOP METRICS ROW ──
        c1, c2, c3, c4 = st.columns(4)
        if metrics:
            with c1:
                st.markdown(f'<div class="metric-card"><h2>{"🟢" if metrics.get("anomaly_rate_percent", 0) < 10 else "🔴"}</h2><p>System Status</p></div>', unsafe_allow_html=True)
            with c2:
                st.markdown(f'<div class="metric-card"><h2>{metrics.get("total_records_processed", 0)}</h2><p>Records Processed</p></div>', unsafe_allow_html=True)
            with c3:
                st.markdown(f'<div class="metric-card"><h2>{metrics.get("total_anomalies_detected", 0)}</h2><p>Anomalies Detected</p></div>', unsafe_allow_html=True)
            with c4:
                st.markdown(f'<div class="metric-card"><h2>{metrics.get("throughput_records_per_sec", 0):.1f}/s</h2><p>Throughput</p></div>', unsafe_allow_html=True)

        st.markdown("---")

        if live_data:
            df = pd.DataFrame(live_data)
            df["timestamp"] = pd.to_datetime(df["timestamp"])

            # ── 📈 LIVE SENSOR TRENDS ──
            st.subheader("📈 Live Sensor Trends")
            t1, t2, t3 = st.columns(3)
            with t1:
                fig = px.line(df, x="timestamp", y="temperature", title="🌡️ Temperature (°C)",
                              color_discrete_sequence=["#ef4444"])
                fig.update_layout(height=280, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig, use_container_width=True)
            with t2:
                fig = px.line(df, x="timestamp", y="vibration", title="⚙️ Vibration (G)",
                              color_discrete_sequence=["#3b82f6"])
                fig.update_layout(height=280, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig, use_container_width=True)
            with t3:
                fig = px.line(df, x="timestamp", y="humidity", title="💧 Humidity (%)",
                              color_discrete_sequence=["#22c55e"])
                fig.update_layout(height=280, margin=dict(l=20, r=20, t=40, b=20))
                st.plotly_chart(fig, use_container_width=True)

            # ── 🔥 ANOMALY SCORE TIMELINE ──
            st.subheader("🔥 Anomaly Score Timeline")
            fig_score = go.Figure()
            fig_score.add_trace(go.Scatter(
                x=df["timestamp"], y=df["anomaly_score"],
                mode="lines+markers",
                marker=dict(
                    color=df["anomaly_score"],
                    colorscale="RdYlGn", cmin=-0.6, cmax=0.1,
                    size=6
                ),
                line=dict(color="#94a3b8", width=1),
                name="Anomaly Score"
            ))
            if "dynamic_threshold" in df.columns:
                fig_score.add_trace(go.Scatter(
                    x=df["timestamp"], y=df["dynamic_threshold"],
                    mode="lines", line=dict(color="#f59e0b", dash="dash", width=2),
                    name="Adaptive Threshold"
                ))
            fig_score.update_layout(height=300, margin=dict(l=20, r=20, t=20, b=20),
                                    yaxis_title="Score (lower = more anomalous)")
            st.plotly_chart(fig_score, use_container_width=True)

            # ── 📊 SENSOR CORRELATION ──
            st.subheader("📊 Sensor Correlation Matrix")
            corr_cols = ["temperature", "vibration", "humidity", "anomaly_score"]
            corr_matrix = df[corr_cols].corr()
            fig_corr = px.imshow(corr_matrix, text_auto=".2f", aspect="auto",
                                 color_continuous_scale="RdBu_r",
                                 title="Feature Correlation Heatmap")
            fig_corr.update_layout(height=350, margin=dict(l=20, r=20, t=40, b=20))
            st.plotly_chart(fig_corr, use_container_width=True)

            # ── ⚠️ REAL-TIME ANOMALY FEED ──
            st.subheader("⚠️ Real-Time Anomaly Feed")
            if anomalies:
                df_a = pd.DataFrame(anomalies)
                for _, row in df_a.tail(10).iterrows():
                    level = row.get("alert_level", "LOW")
                    css_class = f"alert-{level.lower()}" if level in ["HIGH", "MEDIUM", "LOW"] else "alert-low"
                    st.markdown(
                        f'<div class="{css_class}">'
                        f'<strong>{level}</strong> | {row["timestamp"]} | '
                        f'Score: {row["anomaly_score"]:.4f} | '
                        f'T={row["temperature"]:.1f}°C  V={row["vibration"]:.3f}G'
                        f'</div>',
                        unsafe_allow_html=True
                    )
            else:
                st.success("✅ All systems nominal — no anomalies detected")

            # ── 📉 DRIFT INDICATOR ──
            st.subheader("📉 Distribution Drift Indicator")
            dc1, dc2, dc3 = st.columns(3)
            with dc1:
                recent_temp = df["temperature"].tail(20)
                st.metric("Temperature Spread", f"{recent_temp.std():.2f}°C",
                          delta=f"{recent_temp.mean() - 70:.1f} from baseline",
                          delta_color="inverse")
            with dc2:
                recent_vib = df["vibration"].tail(20)
                st.metric("Vibration Spread", f"{recent_vib.std():.3f}G",
                          delta=f"{recent_vib.mean() - 0.5:.3f} from baseline",
                          delta_color="inverse")
            with dc3:
                anomaly_pct = (df["is_anomaly"].sum() / len(df)) * 100
                st.metric("Session Anomaly Rate", f"{anomaly_pct:.1f}%",
                          delta=f"{'High' if anomaly_pct > 10 else 'Normal'}",
                          delta_color="inverse" if anomaly_pct > 10 else "normal")

            # ── RAW DATA ──
            if show_raw:
                st.subheader("📋 Raw Data Stream")
                st.dataframe(df.tail(50), use_container_width=True)

        else:
            st.warning("⏳ Waiting for data stream... Ensure the API, Inference engine, and Sensor Simulator are all running.")

    time.sleep(refresh_rate)